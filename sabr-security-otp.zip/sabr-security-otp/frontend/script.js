
function sendOTP() {
    const phone = document.getElementById('uaeNumber').value;
    fetch('http://localhost:3000/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone })
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById('otpSection').style.display = 'block';
        document.getElementById('message').textContent = data.message || 'OTP sent.';
    })
    .catch(() => {
        document.getElementById('message').textContent = 'Failed to send OTP.';
    });
}

document.getElementById('otpForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const phone = document.getElementById('uaeNumber').value;
    const otp = document.getElementById('otp').value;
    fetch('http://localhost:3000/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, otp })
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById('message').textContent = data.message || 'Login successful!';
    })
    .catch(() => {
        document.getElementById('message').textContent = 'Invalid OTP.';
    });
});
