
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const twilio = require('twilio');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const client = twilio('TWILIO_ACCOUNT_SID', 'TWILIO_AUTH_TOKEN'); // Replace with actual

let otpStore = {};

app.post('/send-otp', async (req, res) => {
    const { phone } = req.body;
    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    otpStore[phone] = otp;

    try {
        await client.messages.create({
            body: `Your SABR OTP is ${otp}`,
            from: 'TWILIO_PHONE_NUMBER', // Replace with verified Twilio number
            to: phone
        });
        res.status(200).json({ message: 'OTP sent' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to send OTP' });
    }
});

app.post('/verify-otp', (req, res) => {
    const { phone, otp } = req.body;
    if (otpStore[phone] === otp) {
        delete otpStore[phone];
        res.status(200).json({ message: 'OTP Verified' });
    } else {
        res.status(400).json({ error: 'Invalid OTP' });
    }
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
